<?php
return[
  "url"=>"http://localhost:8080/images/",
];